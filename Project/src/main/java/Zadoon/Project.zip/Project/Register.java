package Zadoon.Project;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.io.BufferedReader;
import java.io.FileReader;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Register extends Browser_Open  {
	
	@Test(priority = 5)
	public void register() throws Exception {
		
		 String RESET = "\u001B[0m";
		 String RED = "\u001B[31m";
	     String GREEN = "\u001B[32m";
	     String YELLOW = "\u001B[33m";
		
		WebElement login, signUp, Checkbox, Submit, Validation1;
		
		login = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/header/div[1]/div[2]/div[3]/div[2]/div/div[2]/div[2]"));
		login.click();
		
		signUp = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/p/a"));
		signUp.click();
		
		String RCSV = "Register.csv";
		String line;
		String csvSplit = ",";
		
		BufferedReader br = new BufferedReader(new FileReader(RCSV));
		String Header = br.readLine();
		System.out.println(Header);
		
		while((line = br.readLine())!= null) {
			String[] Data = line.split(csvSplit);
			
			String firstName = (Data.length>0 ? Data[0].trim(): " ");
			String lastName = (Data.length>1 ? Data[1].trim(): " ");
			String userName = (Data.length>2 ? Data[2].trim(): " ");
			String email = (Data.length>3 ? Data[3].trim(): " ");
			String password = (Data.length>4 ? Data[4].trim(): " ");
			String companyName = (Data.length>5 ? Data[5].trim(): " ");
			
			System.out.println(YELLOW + line + RESET);
			
			fillInputField(By.name("first_name"),firstName);
			fillInputField(By.name("last_name"),lastName);
			fillInputField(By.name("username"),userName);
			fillInputField(By.name("email"),email);
			fillPasswordField(By.name("password"),password);
			fillInputField(By.name("acf.company_name"),companyName);
			
			Checkbox = driver.findElement(By.xpath("//*[@id=\"agree\"]"));
			Checkbox.click();
			
			Submit = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[7]/button"));
			Submit.click();
			String expectedUrl = "https://zadoon-frontend.vercel.app/login";
			Thread.sleep(5000);
			String actualUrl = driver.getCurrentUrl();
			System.out.println(actualUrl);
			if(expectedUrl.equals(actualUrl)) {
				System.out.println("Registration Successful.");
				driver.navigate().back();
			}
			else {
				System.out.println("Registration form is showing error message.");
				
				String [][] FormValidation = {
						{"//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[1]/div[1]/div","FirstName field is working proper."},
						{"//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[1]/div[2]/div","LastName field is working proper."},
						{"//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[2]/div","UserName field is working proper."},
						{"//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[3]/div","Email field is working proper."},
						{"//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[4]/div[2]","Password field is working proper."},
					};
				for(String[] Validation : FormValidation) {
					try {
						Validation1 = driver.findElement(By.xpath(Validation[0]));
						String ValidationError = Validation1.getText();
						System.out.println(RED + ValidationError + RESET);
					}
					catch(Exception e) {
						System.out.println(GREEN + Validation[1] + RESET);
					}
				}
				driver.navigate().refresh();
			}
		}
		br.close();
	}
	public void fillInputField(By locator, String value) {
		WebElement element = driver.findElement(locator);
		element.clear();
		element.sendKeys(value);
	}
	public void fillPasswordField(By locator, String value) {
		WebElement element = driver.findElement(locator);
		element.sendKeys(Keys.CONTROL+"a");
		element.sendKeys(Keys.DELETE);
		element.sendKeys(value);
	}
}

