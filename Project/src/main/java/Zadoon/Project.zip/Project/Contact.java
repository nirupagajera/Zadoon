package Zadoon.Project;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;


public class Contact extends Browser_Open {
	@Test(priority = 2)	
	public void Contact_UsTest() throws Exception{
				
			WebElement Page, Submit, Validation;
			 String RESET = "\u001B[0m";
			 String RED = "\u001B[31m";
		     String GREEN = "\u001B[32m";
		     String YELLOW = "\u001B[33m";
		        
			Page = driver.findElement(By.linkText("Contact Us"));
			Page.click();
			Thread.sleep(2000);
			System.out.println("Contact Us Page : " + driver.getTitle());
				
	        String inputcsv = "Data.csv";
	        String outputcsv = "Result.csv";
	        String line;
	        String csvSplitBy = ",";
	        
	        // Reading the CSV file
	        BufferedReader br = new BufferedReader(new FileReader(inputcsv));
	        BufferedWriter bw = new BufferedWriter(new FileWriter(outputcsv));
	        
        
	        // Skipping the header (if any)
	        
	        String header = br.readLine();
	        
	        if(header != null) {
	        	bw.write(header + ", Status\n");
	        }
	       
	        while ((line = br.readLine()) != null && !line.equals("")) {
	  	      //Splitting CSV line into an array

	        	String[] formData = line.split(csvSplitBy);

	            // Assuming CSV columns are: Name, Email, Phone, Message
	            String subject = (formData.length>0 ? formData[0].trim(): " ");
	            String firstname = (formData.length>1 ? formData[1].trim(): " ");
	            String lastname = (formData.length>2 ? formData[2].trim(): " ");
	            String email = (formData.length>3 ? formData[3].trim(): " ");
	            String phone = (formData.length>4 ? formData[4].trim(): " ");
	            String message = (formData.length>5 ? formData[5].trim(): " ");
	            
                 
		        /*WebElement Dropdown = driver.findElement(By.id("floatingSelect"));
		        
		        Select dropdown = new Select(Dropdown);
		        
		        dropdown.selectByVisibleText("Solution");*/
	            
	            fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[1]/input"),subject);
	            fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[2]/div[1]/input"),firstname);
	            fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[2]/div[2]/input"),lastname);
	            fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[3]/div[1]/input"),email);
	            fillPhoneField(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[3]/div[2]/div/input"),phone);
	            fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[4]/textarea"),message);
	                 
		        Submit = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[5]/button"));
		        Submit.click();
		        // Print Iteration.
		        System.out.println(YELLOW + line + RESET);
		       
		        Thread.sleep(5000);
		        String Expectedurl = "https://zadoon-frontend.vercel.app/thank-you";
		        String currentUrl = driver.getCurrentUrl();
		        
		        if (Expectedurl.equals(currentUrl)){
		        	
		        	System.out.println(GREEN + "Form is submitted successfully" + RESET);
		        	bw.write(line + ",Pass\n");
		        	driver.navigate().back();
		        }
		        else {
				    System.out.println(RED + "Form is showing error message" + RESET);
			        //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			        
			        String [][] Datavalidation= {
			        		{"//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[1]/div", "Subject field is working proper."},
			        		{"//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[2]/div[1]/div", "FirstName field is working proper."},
			        		{"//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[2]/div[2]/div", "LastName field is working proper."},
			        		{"//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[3]/div[1]/div", "Email field is working proper."},
			        		{"//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[3]/div[2]/div[2]", "Phone field is working proper."},
			        		{"//*[@id=\"__next\"]/div/div[3]/div/div/div[2]/form/div[4]/div", "Message field is working proper."},
			        };
			        
			        for(String[] Data : Datavalidation) {
			        	try {
			        		Validation = driver.findElement(By.xpath(Data[0]));
			        		String ValidationError = Validation.getText();
			        		System.out.println(RED + ValidationError +RESET);
			        	}
			        	catch(Exception e){
			        		System.out.println(GREEN + Data[1] + RESET);
			        	}
			        }
				   
				    bw.write(line + ",Failed\n");
				    driver.navigate().refresh();
				    Thread.sleep(2000);
				}
	        } 

		        br.close();
		        bw.close();             
		   }
	
	public void fillInputField(By locator, String value) {
		WebElement element = driver.findElement(locator);
		element.clear();
		element.sendKeys(value);
	}
	public void fillPhoneField(By locator, String value) {
		WebElement element = driver.findElement(locator);
		String phoneValue = element.getAttribute("value");
		for(int i=0;i<phoneValue.length();i++) {
			element.sendKeys(Keys.BACK_SPACE);
		}
		element.sendKeys(value);
	}
}