package Zadoon.Project;
import java.time.Duration;

import org.openqa.selenium.By;
import java.io.BufferedReader;
import org.openqa.selenium.Keys;
import java.io.FileReader;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class freemachine extends Browser_Open {
	
	public String CsvSplit = ",";
	public String line;
    
    @Test(priority = 3)
    public void login()throws Exception {
    	
    	WebElement button, Email, Password, Submit, Validation;
    	
    	 String RESET = "\u001B[0m";
		 String RED = "\u001B[31m";
	     String GREEN = "\u001B[32m";
    	
        button = driver.findElement(By.linkText("Free Machine Evaluation"));
        button.click();
        
        String InputFile = "login.csv";
    	
    	BufferedReader read = new BufferedReader(new FileReader(InputFile));
        
        Thread.sleep(2000);
        
        String CurrentURl = driver.getCurrentUrl();
        System.out.println(CurrentURl);
        if (CurrentURl.contains("login")) {
        	
        	System.out.println("You need to login first");
        	
        	String header = read.readLine();
        	
        	System.out.println(header);
        	
        	while((line=read.readLine())!=null) {
        		
        	String[] formdata = line.split(CsvSplit);
        	
        	String email = (formdata.length>0 ? formdata[0].trim(): " ");
        	String password = (formdata.length>1 ? formdata[1].trim(): " ");
        	  	
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        	Email = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[1]/input"));
        	Email.clear();
        	Email.sendKeys(email);
        	
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        	
        	Password = driver.findElement(By.name("password"));
        	Password.sendKeys(Keys.CONTROL + "a");
        	Password.sendKeys(Keys.DELETE);
        	
        	Password.sendKeys(password);
        	        	
        	Thread.sleep(1000);

        	Submit = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[4]/button"));
        	Submit.click();
        	Thread.sleep(3000);
        	String ExpectedUrl = "https://zadoon-frontend.vercel.app/login";
        	String CurrentUrl = driver.getCurrentUrl();
        	if(ExpectedUrl.equals(CurrentUrl)) {
        		
        		System.out.println(RED + "You are entering invalid username or password." + RESET);
        		
        		String [][] Datavalidation = {
        				{"Toastify__toast-body", "Email field is working proper."},
        				{"Toastify__toast-body", "Password field is working proper."}
        		};
        		
        		for(String [] data: Datavalidation) {
				    try {
					    Validation = driver.findElement(By.className(data[0]));
					    String ValidationError = Validation.getText();
					    System.out.println(RED + ValidationError + RESET);
					    
					    }
				    catch(Exception e) {
				    	System.out.println(GREEN + data[1] + RESET);
				    }
        	}
        	}
        	else {
        		
        		System.out.println(GREEN + "You are Successfully login." + RESET);
        		
        	}
        	Thread.sleep(2000);
            }        	        	
        	read.close();
        	
        }
       else
	       {
	        	System.out.println("You are already login");
    	
	       }
        
        driver.navigate().refresh();
   }
        
}	
