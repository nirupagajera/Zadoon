package Zadoon.Project;

import java.io.BufferedReader;
import java.io.FileReader;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class FreeMachineAfterLogin extends freemachine {
    public String line;
    public String CsvSplit = ",";

    @Test(priority = 4)
    public void machine() throws Exception {
        WebElement FreeMachine,Submit;
        String Icsv = "FreeMachine.csv";
        BufferedReader br = new BufferedReader(new FileReader(Icsv));
        String header = br.readLine();
        System.out.println(header);
        while ((line = br.readLine()) != null) {
            String[] Data = line.split(CsvSplit);
            String firstname1 = (Data.length>0 ? Data[0].trim(): " ");
            String lastname1 = (Data.length>1 ? Data[1].trim(): " ");
            String phone1 = (Data.length>2 ? Data[2].trim(): " ");
            String model1 = (Data.length>3 ? Data[3].trim(): " ");
            String manufacturer1 = (Data.length>4 ? Data[4].trim(): " ");
            String hours1 = (Data.length>5 ? Data[5].trim(): " ");
            String message1 = (Data.length>6 ? Data[6].trim(): " ");

            FreeMachine = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/header/div[1]/div[2]/div[3]/div[2]/div/div[2]/div/button"));
            FreeMachine.click();
            
            fillInputField(By.xpath("/html/body/div[2]/div[2]/section/div[2]/form/div[1]/div[1]/input"), firstname1);
            fillInputField(By.xpath("/html/body/div[2]/div[2]/section/div[2]/form/div[1]/div[2]/input"), lastname1);
            fillPhoneField(By.xpath("/html/body/div[2]/div[2]/section/div[2]/form/div[2]/div[2]/div/input"), phone1);
            fillInputField(By.xpath("/html/body/div[2]/div[2]/section/div[2]/form/div[3]/div[1]/input"), model1);
            fillInputField(By.xpath("/html/body/div[2]/div[2]/section/div[2]/form/div[3]/div[2]/input"), manufacturer1);
            fillInputField(By.xpath("/html/body/div[2]/div[2]/section/div[2]/form/div[4]/div/input"), hours1);
            fillInputField(By.xpath("/html/body/div[2]/div[2]/section/div[2]/form/div[5]/textarea"), message1);

            Submit = driver.findElement(By.xpath("//*[@id=\":R8pmH2:\"]/form/div[6]/button"));
            Submit.click();
            Thread.sleep(1000);

            WebElement toastMessage = driver.findElement(By.className("Toastify__toast-body"));
            String Test = toastMessage.getText();
            System.out.println(Test);
            if (toastMessage.getText().contains("Your request has been submitted. A zadoon representative will contact you to follow up.")) {
                System.out.println("Submitted Successfully.");
            } else {
                System.out.println("Form is showing an error message.");
            }
        }
        br.close();
    }

    private void fillInputField(By locator, String value) {
        WebElement element = driver.findElement(locator);
        element.clear();
        element.sendKeys(value);
    }

    private void fillPhoneField(By locator, String value) {
        WebElement element = driver.findElement(locator);
        String currentPhone = element.getAttribute("value");
        for (int i = 0; i < currentPhone.length(); i++) {
            element.sendKeys(Keys.BACK_SPACE);
        }
        element.sendKeys(value);
    }
}

