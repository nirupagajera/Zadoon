package Zadoon.Project;

import java.util.HashSet;
//import java.io.BufferedReader;
//import java.io.FileReader;
import java.util.List;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import java.time.Duration;
import java.util.Set;


public class Sell_Request extends freemachine{

	@Test(priority = 8)
	public void Sell_Form() throws Exception  {
		
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
		WebElement Profile_Icon, Dashboard_URL, Sell_Request_tab, Request_Want_to_Sell_Button , category, Search_Category, manufacturer,
		Search_Manufacturer , model, Search_Model , year , country , Search_Country, Popover, CountryDropdown, Scroll_Element;
		
		Profile_Icon = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/header/div[1]/div[2]/div[3]/div[2]/div/div[2]/button/span[2]"));
		Profile_Icon.click();
			
		Dashboard_URL = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/header/div[1]/div[2]/div[3]/div[2]/div/div[2]/ul/li[1]/a"));
		Dashboard_URL.click();
		
		Sell_Request_tab = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[1]/div/ul/li[2]"));
		Sell_Request_tab.click();
		
		Request_Want_to_Sell_Button = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/div[1]/div/a"));
		Request_Want_to_Sell_Button.click();
		
		String CSV = "Sell.csv";
		String line;
		String CSVSplit = ",";
		
		//BufferedReader br = new BufferedReader(new FileReader(CSV));
		
		//String header = br.readLine();
		
		//while((line = br.readLine())!= null) {
			
			//String [] FormData = line.split(CSVSplit);
			
//			String Category = (FormData.length> 0)? FormData[0].trim() : " ";
//			String Manufacturer = (FormData.length> 1)? FormData[1].trim() : " ";
//			String Model = (FormData.length> 2)? FormData[2].trim() : " ";
//			String Year = (FormData.length> 3)? FormData[3].trim() : " ";
//			String Hours = (FormData.length> 4)? FormData[4].trim() : " ";
//			String Serial_Number = (FormData.length> 5)? FormData[5].trim() : " ";
//			String Country = (FormData.length> 6)? FormData[6].trim() : " ";
//			String State = (FormData.length> 7)? FormData[7].trim() : " ";
//			String City = (FormData.length> 8)? FormData[8].trim() : " ";
//			String Image_Uploader = (FormData.length> 9)? FormData[9].trim() : " ";
//			String Drive_URL = (FormData.length> 10)? FormData[10].trim() : " ";
//			String Targeted_Price = (FormData.length> 11)? FormData[11].trim() : " ";
//			String Product_Description = (FormData.length> 12)? FormData[12].trim() : " ";
//			String Are_you_Open = (FormData.length> 13)? FormData[13].trim() : " ";
			
			category = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[1]/div/div[2]/div/div/input"));
			category.clear();
			category.click();
			
			Thread.sleep(3000);
			Search_Category = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[1]/div/div[2]/div/ul")); 
			
				List<WebElement> Category_options = Search_Category.findElements(By.tagName("li"));
				boolean categoryFound = false;

				for (WebElement option : Category_options)	
				{
					    if (option.getText().equalsIgnoreCase("Scissor Lift"))
					    {
					        option.click(); // click the desired option
					        categoryFound = true;
					        break;
					    }
				    
				}
				
				if (!categoryFound) {
				    List<WebElement> Category_options_Strong = Search_Category.findElements(By.tagName("strong"));
				    
				    for (WebElement option1 : Category_options_Strong) {
				        if (option1.getText().trim().equalsIgnoreCase("Scissor Lift")) {
				            option1.click(); // Click the desired option
				            categoryFound = true;
				        }
				    }
				}


			//Manufacturer Selection
			
			manufacturer = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[2]/div/div[2]/div/div/input"));
			manufacturer.clear();
			manufacturer.click();
			
			Thread.sleep(3000);
			Search_Manufacturer = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[2]/div/div[2]/div/ul"));
			
			List<WebElement> Manufacturer_values = Search_Manufacturer.findElements(By.tagName("li"));
			for(WebElement value : Manufacturer_values) {
				if(value.getText().equals("JLG")) {
					value.click();
					break;
				}
			}

			//Model Selection

			model = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[3]/div/div[2]/div/div/input"));
			model.clear();
			model.click();
			
			Thread.sleep(3000);
			Search_Model = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[3]/div/div[2]/div/ul"));
			
			List<WebElement> Model_datas = Search_Model.findElements(By.tagName("li"));
			for(WebElement data : Model_datas) {
				if(data.getText().equals("40RTS")) {
					data.click();
					break;
					
				}
			}
			
//			CountryDropdown = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[7]/div/div[2]/div[1]/label/select"));
//			
//			Select selectCountry = new Select(CountryDropdown);
//			
//			selectCountry.selectByVisibleText("India");
//			
//			WebElement selectedOption = selectCountry.getFirstSelectedOption();
//		    System.out.println("Selected Country: " + selectedOption.getText());
			
			//try {
		        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(5));

		        WebElement dropdownButton = driver.findElement(By.xpath("//*[@id='__next']/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[7]/div/div[2]/div[2]"));
		        dropdownButton.click();
		        Thread.sleep(1000); // Wait for the dropdown to open

		        WebElement dropdownList = driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div/div/ul"));
		        
			    WebElement Scrollable_Element = driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div/div/ul/div"));


		        JavascriptExecutor js = (JavascriptExecutor) driver;
		        boolean countryFound = false;
		        int maxScroll = 43;

		        
		        for (int i = 0; i < maxScroll; i++){
		            List<WebElement> options = dropdownList.findElements(By.tagName("li"));
		            for (WebElement option : options) {
		                String text = option.getText().trim();
		                System.out.println("Checking Country: " + text);

		                if (text.equalsIgnoreCase("India")) {
		                    option.click(); // Select the country
		                    System.out.println("✅ Selected: " + "India");
		                    countryFound = true;
		                    return; // Exit function
		                }
		            }
		            
		            js.executeScript("arguments[0].scrollTop += 200;", Scrollable_Element);
		            Thread.sleep(1000);
		            		            
		        }
		        if (!countryFound) {
		            System.out.println("❌ India not found in the dropdown!");
		            Actions action = new Actions(driver);
		            action.sendKeys(Keys.ESCAPE).perform();		       
		            }
	}
}
		         




