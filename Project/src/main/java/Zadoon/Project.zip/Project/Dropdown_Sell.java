package Zadoon.Project;

import java.time.Duration;
import java.util.HashSet;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import java.util.Set;
import java.util.HashSet;


public class Dropdown_Sell extends freemachine{

	@Test(priority = 9)
	public void Dropdown_Country() throws Exception {
		// TODO Auto-generated constructor stub
		
		WebElement Profile_Icon = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/header/div[1]/div[2]/div[3]/div[2]/div/div[2]/button/span[2]"));
		Profile_Icon.click();
			
		WebElement Dashboard_URL = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/header/div[1]/div[2]/div[3]/div[2]/div/div[2]/ul/li[1]/a"));
		Dashboard_URL.click();
		
		WebElement Sell_Request_tab = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[1]/div/ul/li[2]"));
		Sell_Request_tab.click();
		
		WebElement Request_Want_to_Sell_Button = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/div[1]/div/a"));
		Request_Want_to_Sell_Button.click();
		
		Thread.sleep(5000);
		
		 WebElement countryDropdown = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[7]/div/div[2]/div[2]"));
	        countryDropdown.click();
	        Thread.sleep(2000);

	     WebElement Listbox = driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div/div/ul"));
	     
	     WebElement Scrollable_Element = driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div/div/ul/div"));
	     
	     int maxScrolls = 15;
	     for(int i = 0;i<Listbox.getSize().getHeight();i++) {
	    	 System.out.println(i);
	    	 
	    	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

	    	 wait.until(ExpectedConditions.visibilityOfAllElements(Listbox));

	    	 List<WebElement> list = driver.findElements(By.xpath("/html/body/div[2]/div/div[1]/div/div/ul/div/div/li"));
	    	 
	    	 //((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('value', 'Option 1')", Scrollable_Element);

	    	 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollTop += 200", Scrollable_Element);
	    	 
	    	 for(WebElement Data : list) {
		    	 System.out.println(Data);
	    		 if(Data.getText().equals("India")) {
	    			 Data.click();
	    		 }
	    		 
	    	 }
	     }
	     
	}
	
}
