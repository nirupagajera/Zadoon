package Zadoon.Project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Buy_Request extends freemachine {
	 	
	@Test(priority = 6)
	public void buy_request() throws Exception {
			
		WebElement Profile_Icon, Dashboard_URL, Buy_Request_Tab, Request_Want_To_Buy, Category, Search_Category, Manufacturer, 
		Search_Manufacturer, Model, Search_Model, Submit, Validation_Message;
		
		 String RESET = "\u001B[0m";
		 String RED = "\u001B[31m";
	     String GREEN = "\u001B[32m";
	     String YELLOW = "\u001B[33m";
	  	     
		
	    Profile_Icon = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/header/div[1]/div[2]/div[3]/div[2]/div/div[2]/button/span[2]"));
		Profile_Icon.click();
			
		Dashboard_URL = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/header/div[1]/div[2]/div[3]/div[2]/div/div[2]/ul/li[1]/a"));
		Dashboard_URL.click();
			
		Buy_Request_Tab = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[1]/div/ul/li[1]/a"));
		Buy_Request_Tab.click();

		Request_Want_To_Buy = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/div[1]/div/a"));
		Request_Want_To_Buy.click();
		
			
		String CSV = "Buy.csv";
		String line;
		String CSVsplit = ",";
		BufferedReader br = new BufferedReader(new FileReader(CSV));
		
		String header = br.readLine();
		System.out.println(header);
		while((line=br.readLine())!=null) {
			String [] Index = line.split(CSVsplit);
			
			
			String category = (Index.length > 0) ? Index[0].trim() : "";
			String manufacturer = (Index.length > 1) ? Index[1].trim() : "";
			String model = (Index.length > 2) ? Index[2].trim() : "";
			String year_min = (Index.length > 3) ? Index[3].trim() : "";
			String year_max = (Index.length > 4) ? Index[4].trim() : "";
			String hour_min = (Index.length > 5) ? Index[5].trim() : "";
			String hour_max = (Index.length > 6) ? Index[6].trim() : "";
			String budget_min = (Index.length > 7) ? Index[7].trim() : "";
			String budget_max = (Index.length > 8) ? Index[8].trim() : "";
			String phone_number = (Index.length > 9) ? Index[9].trim() : "";
			String additional_notes = (Index.length > 10) ? Index[10].trim() : "";
			

			
			System.out.println(YELLOW + line + RESET);
			
		//Category Selection
			
		Category = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[1]/div/div[2]/div/div/input"));
		Category.clear();
		Category.click();
		
		Thread.sleep(3000);
		Search_Category = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[1]/div/div[2]/div/ul")); 
		
			List<WebElement> Category_options = Search_Category.findElements(By.tagName("li"));
			boolean categoryFound = false;

			for (WebElement option : Category_options)	
			{
				    if (option.getText().equals(category))
				    {
				        option.click(); // click the desired option
				        categoryFound = true;
				        break;
				    }
			    
			}
			
			if (!categoryFound) {
			    List<WebElement> Category_options_Strong = Search_Category.findElements(By.tagName("strong"));
			    
			    for (WebElement option1 : Category_options_Strong) {
			        if (option1.getText().trim().equalsIgnoreCase(category)) {
			            option1.click(); // Click the desired option
			            categoryFound = true;
			            break;
			        }
			    }
			}


		//Manufacturer Selection
		
		Manufacturer = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[2]/div/div[2]/div/div/input"));
		Manufacturer.clear();
		Manufacturer.click();
		
		Thread.sleep(3000);
		Search_Manufacturer = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[2]/div/div[2]/div/ul"));
		
		List<WebElement> Manufacturer_values = Search_Manufacturer.findElements(By.tagName("li"));
		for(WebElement value : Manufacturer_values) {
			if(value.getText().equals(manufacturer)) {
				value.click();
				break;
			}
		}

		//Model Selection

		Model = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[3]/div/div[2]/div/div/input"));
		Model.clear();
		Model.click();
		
		Thread.sleep(3000);
		Search_Model = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[3]/div/div[2]/div/ul"));
		
		List<WebElement> Model_datas = Search_Model.findElements(By.tagName("li"));
		for(WebElement data : Model_datas) {
			if(data.getText().equals(model)) {
				data.click();
				break;
				
			}
		}
		
		fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[1]/div/div[2]/div[1]/input"),year_min);
		fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[1]/div/div[2]/div[3]/input"),year_max);
		fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[2]/div/div[2]/div[1]/input"),hour_min);
		fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[2]/div/div[2]/div[3]/input"),hour_max);
		fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[3]/div/div[2]/div[1]/input"),budget_min);
		fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[3]/div/div[2]/div[3]/input"),budget_max);
		fillPhoneField(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[4]/div/div[2]/div/input"),phone_number);
		fillInputField(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/div/textarea"),additional_notes);
		
		Submit = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[3]/div/button"));
		Submit.click();
		
		String Expected_Url = "https://zadoon-frontend.vercel.app/profile/buy-request";
		Thread.sleep(5000);
		String Current_Url = driver.getCurrentUrl();
		
		if(Expected_Url.equals(Current_Url)) {
			System.out.println(GREEN + "Form is submitted successfully." + RESET);
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-250)");

			Request_Want_To_Buy = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[2]/div/div[2]/div[1]/div/a"));
			Request_Want_To_Buy.click(); 
			

		}
		else {
			System.out.println(RED + "Form is showing error message." + RESET);	
			
			String[][] FormValidation = {
					{"//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[1]/div/div[3]", "Category field is working proper."},
					{"//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[2]/div/div[3]","Manufacturer field is working proper."},
					{"//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[1]/ul/li[3]/div/div[3]","Model field is working proper."},
					{"//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[1]/div/div[2]/div[1]/div","Min year field is working proper."},
					{"//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[1]/div/div[2]/div[3]/div","Max year field is working proper."},
					{"//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[2]/div/div[2]/div[1]/div","Min hour field is working proper."},
					{"//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[2]/div/div[2]/div[3]/div","Max hour field is working proper."},
					{"//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[3]/div/div[2]/div[1]/div","Min budget field is working proper."},
					{"//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[3]/div/div[2]/div[3]/div","Max budget field is working proper."},
					{"//*[@id=\"__next\"]/div/div[2]/div/div[2]/form/div/div/div[2]/div/ul/li[4]/div/div[3]","Phone number field is working proper."},
			
			};
			for(String [] Validation : FormValidation) {
				try {
				Validation_Message = driver.findElement(By.xpath(Validation[0]));
				String Validation_Error = Validation_Message.getText();
				System.out.println(RED + Validation_Error + RESET);
				}
				catch(Exception e) {
					System.out.println(GREEN + Validation[1] + RESET);
				}
			}
			String currentUrl = driver.getCurrentUrl(); 
			String cleanUrl = currentUrl.split("\\?")[0]; // Remove query parameters
			driver.get(cleanUrl);
		}
		}
		System.out.println("1");
		br.close();
	}
	
	public void fillInputField(By locator, String Value) {
		WebElement element = driver.findElement(locator);
		element.clear();
		element.sendKeys(Value);
		}
	public void fillPhoneField(By locator, String Value) {
		WebElement element = driver.findElement(locator);
		String Current_Phone = element.getAttribute("value");
		for(int i=0; i<Current_Phone.length(); i++) {
			element.sendKeys(Keys.BACK_SPACE);
		}
		element.sendKeys(Value);
	}
	
}
