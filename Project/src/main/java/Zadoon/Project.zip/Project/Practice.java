package Zadoon.Project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.time.Duration;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Practice {
	
	public WebDriver driver;
	
	
	@Test(priority = 1)
	public void setup() {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.zadoon.com/");
		System.out.println("Page Title is" + driver.getTitle());
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
	}
	
	@Test(priority = 2)
	public void contact() throws Exception {
		
		WebElement Page, Email, Password, Submit,EmailValidation,PasswordValidation ;
		
		String Input = "login.csv";
		String line;
		String CsvSplit = ",";
		
		Page = driver.findElement(By.linkText("Login"));
		Page.click();
		
		BufferedReader br = new BufferedReader(new FileReader(Input));
		
		String header = br.readLine();
		
		while ((line = br.readLine())!= null) {
			
			String[] FormData = line.split(CsvSplit);
			
			String email = FormData[0];
			String password = FormData[1];
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Email = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[1]/input"));
		Email.clear();
		Email.sendKeys(email);
		
		Password = driver.findElement(By.name("password"));
		Password.clear();
		Password.sendKeys(password);
		
		Submit = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[4]/button"));
		Submit.click();
		System.out.println(line);
		
		Thread.sleep(2000);
		String CurrentURl = driver.getCurrentUrl();
		if(CurrentURl.contains("profile")) {
			System.out.println("You are logged in successfully.");
		}
		else {
			System.out.println("Form is Showing Error");
			try {
				EmailValidation = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[1]/div"));
				String EmailError = EmailValidation.getText();
				System.out.println(EmailError);
			}
			catch (Exception e) {
				System.out.println("Your Email field is correct");
			}
			try {
				PasswordValidation = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[1]/div/div[2]/div/div/form/div[2]/div[2]"));
				String PasswordError = PasswordValidation.getText();
				System.out.println(PasswordError);
			}
			catch(Exception e){
				System.out.println("Your password field is correct.");
			}
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		}
		}
		br.close();
		
	}
	
}


